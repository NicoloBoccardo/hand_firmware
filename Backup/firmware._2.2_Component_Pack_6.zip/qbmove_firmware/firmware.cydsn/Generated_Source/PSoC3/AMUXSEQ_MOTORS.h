/*******************************************************************************
* File Name: AMUXSEQ_MOTORS.h
* Version 1.70
*
*  Description:
*    This file contains the constants and function prototypes for the AMuxSeq.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUXSEQ_AMUXSEQ_MOTORS_H)
#define CY_AMUXSEQ_AMUXSEQ_MOTORS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void AMUXSEQ_MOTORS_Start(void);
void AMUXSEQ_MOTORS_Init(void);
void AMUXSEQ_MOTORS_Stop(void);
void AMUXSEQ_MOTORS_Next(void);
void AMUXSEQ_MOTORS_DisconnectAll(void);
int8 AMUXSEQ_MOTORS_GetChannel(void);


/***************************************
*     Initial Parameter Constants
***************************************/
#define AMUXSEQ_MOTORS_CHANNELS  3
#define AMUXSEQ_MOTORS_MUXTYPE   1


/***************************************
*             API Constants
***************************************/

#define AMUXSEQ_MOTORS_MUX_SINGLE   1
#define AMUXSEQ_MOTORS_MUX_DIFF     2

#endif /* CY_AMUXSEQ_AMUXSEQ_MOTORS_H */


/* [] END OF FILE */
