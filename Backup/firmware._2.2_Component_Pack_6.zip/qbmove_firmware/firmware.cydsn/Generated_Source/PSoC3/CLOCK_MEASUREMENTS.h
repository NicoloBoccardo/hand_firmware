/*******************************************************************************
* File Name: CLOCK_MEASUREMENTS.h
* Version 2.0
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_CLOCK_MEASUREMENTS_H)
#define CY_CLOCK_CLOCK_MEASUREMENTS_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_0 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void CLOCK_MEASUREMENTS_Start(void) ;
void CLOCK_MEASUREMENTS_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void CLOCK_MEASUREMENTS_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void CLOCK_MEASUREMENTS_StandbyPower(uint8 state) ;
void CLOCK_MEASUREMENTS_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 CLOCK_MEASUREMENTS_GetDividerRegister(void) ;
void CLOCK_MEASUREMENTS_SetModeRegister(uint8 modeBitMask) ;
void CLOCK_MEASUREMENTS_ClearModeRegister(uint8 modeBitMask) ;
uint8 CLOCK_MEASUREMENTS_GetModeRegister(void) ;
void CLOCK_MEASUREMENTS_SetSourceRegister(uint8 clkSource) ;
uint8 CLOCK_MEASUREMENTS_GetSourceRegister(void) ;
#if defined(CLOCK_MEASUREMENTS__CFG3)
void CLOCK_MEASUREMENTS_SetPhaseRegister(uint8 clkPhase) ;
uint8 CLOCK_MEASUREMENTS_GetPhaseRegister(void) ;
#endif /* defined(CLOCK_MEASUREMENTS__CFG3) */

#define CLOCK_MEASUREMENTS_Enable()                       CLOCK_MEASUREMENTS_Start()
#define CLOCK_MEASUREMENTS_Disable()                      CLOCK_MEASUREMENTS_Stop()
#define CLOCK_MEASUREMENTS_SetDivider(clkDivider)         CLOCK_MEASUREMENTS_SetDividerRegister(clkDivider, 1)
#define CLOCK_MEASUREMENTS_SetDividerValue(clkDivider)    CLOCK_MEASUREMENTS_SetDividerRegister((clkDivider) - 1, 1)
#define CLOCK_MEASUREMENTS_SetMode(clkMode)               CLOCK_MEASUREMENTS_SetModeRegister(clkMode)
#define CLOCK_MEASUREMENTS_SetSource(clkSource)           CLOCK_MEASUREMENTS_SetSourceRegister(clkSource)
#if defined(CLOCK_MEASUREMENTS__CFG3)
#define CLOCK_MEASUREMENTS_SetPhase(clkPhase)             CLOCK_MEASUREMENTS_SetPhaseRegister(clkPhase)
#define CLOCK_MEASUREMENTS_SetPhaseValue(clkPhase)        CLOCK_MEASUREMENTS_SetPhaseRegister((clkPhase) + 1)
#endif /* defined(CLOCK_MEASUREMENTS__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define CLOCK_MEASUREMENTS_CLKEN              (* (reg8 *) CLOCK_MEASUREMENTS__PM_ACT_CFG)
#define CLOCK_MEASUREMENTS_CLKEN_PTR          ((reg8 *) CLOCK_MEASUREMENTS__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define CLOCK_MEASUREMENTS_CLKSTBY            (* (reg8 *) CLOCK_MEASUREMENTS__PM_STBY_CFG)
#define CLOCK_MEASUREMENTS_CLKSTBY_PTR        ((reg8 *) CLOCK_MEASUREMENTS__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define CLOCK_MEASUREMENTS_DIV_LSB            (* (reg8 *) CLOCK_MEASUREMENTS__CFG0)
#define CLOCK_MEASUREMENTS_DIV_LSB_PTR        ((reg8 *) CLOCK_MEASUREMENTS__CFG0)
#define CLOCK_MEASUREMENTS_DIV_PTR            ((reg16 *) CLOCK_MEASUREMENTS__CFG0)

/* Clock MSB divider configuration register. */
#define CLOCK_MEASUREMENTS_DIV_MSB            (* (reg8 *) CLOCK_MEASUREMENTS__CFG1)
#define CLOCK_MEASUREMENTS_DIV_MSB_PTR        ((reg8 *) CLOCK_MEASUREMENTS__CFG1)

/* Mode and source configuration register */
#define CLOCK_MEASUREMENTS_MOD_SRC            (* (reg8 *) CLOCK_MEASUREMENTS__CFG2)
#define CLOCK_MEASUREMENTS_MOD_SRC_PTR        ((reg8 *) CLOCK_MEASUREMENTS__CFG2)

#if defined(CLOCK_MEASUREMENTS__CFG3)
/* Analog clock phase configuration register */
#define CLOCK_MEASUREMENTS_PHASE              (* (reg8 *) CLOCK_MEASUREMENTS__CFG3)
#define CLOCK_MEASUREMENTS_PHASE_PTR          ((reg8 *) CLOCK_MEASUREMENTS__CFG3)
#endif /* defined(CLOCK_MEASUREMENTS__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define CLOCK_MEASUREMENTS_CLKEN_MASK         CLOCK_MEASUREMENTS__PM_ACT_MSK
#define CLOCK_MEASUREMENTS_CLKSTBY_MASK       CLOCK_MEASUREMENTS__PM_STBY_MSK

/* CFG2 field masks */
#define CLOCK_MEASUREMENTS_SRC_SEL_MSK        CLOCK_MEASUREMENTS__CFG2_SRC_SEL_MASK
#define CLOCK_MEASUREMENTS_MODE_MASK          (~(CLOCK_MEASUREMENTS_SRC_SEL_MSK))

#if defined(CLOCK_MEASUREMENTS__CFG3)
/* CFG3 phase mask */
#define CLOCK_MEASUREMENTS_PHASE_MASK         CLOCK_MEASUREMENTS__CFG3_PHASE_DLY_MASK
#endif /* defined(CLOCK_MEASUREMENTS__CFG3) */

#endif /* CY_CLOCK_CLOCK_MEASUREMENTS_H */


/* [] END OF FILE */
