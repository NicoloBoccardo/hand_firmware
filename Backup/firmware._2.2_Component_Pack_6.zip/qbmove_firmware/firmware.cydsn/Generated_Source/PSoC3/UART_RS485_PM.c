/*******************************************************************************
* File Name: UART_RS485_PM.c
* Version 2.30
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "UART_RS485.h"


/***************************************
* Local data allocation
***************************************/

static UART_RS485_BACKUP_STRUCT  UART_RS485_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: UART_RS485_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART_RS485_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART_RS485_SaveConfig(void)
{
    #if (CY_UDB_V0)

        #if(UART_RS485_CONTROL_REG_REMOVED == 0u)
            UART_RS485_backup.cr = UART_RS485_CONTROL_REG;
        #endif /* End UART_RS485_CONTROL_REG_REMOVED */

        #if( (UART_RS485_RX_ENABLED) || (UART_RS485_HD_ENABLED) )
            UART_RS485_backup.rx_period = UART_RS485_RXBITCTR_PERIOD_REG;
            UART_RS485_backup.rx_mask = UART_RS485_RXSTATUS_MASK_REG;
            #if (UART_RS485_RXHW_ADDRESS_ENABLED)
                UART_RS485_backup.rx_addr1 = UART_RS485_RXADDRESS1_REG;
                UART_RS485_backup.rx_addr2 = UART_RS485_RXADDRESS2_REG;
            #endif /* End UART_RS485_RXHW_ADDRESS_ENABLED */
        #endif /* End UART_RS485_RX_ENABLED | UART_RS485_HD_ENABLED*/

        #if(UART_RS485_TX_ENABLED)
            #if(UART_RS485_TXCLKGEN_DP)
                UART_RS485_backup.tx_clk_ctr = UART_RS485_TXBITCLKGEN_CTR_REG;
                UART_RS485_backup.tx_clk_compl = UART_RS485_TXBITCLKTX_COMPLETE_REG;
            #else
                UART_RS485_backup.tx_period = UART_RS485_TXBITCTR_PERIOD_REG;
            #endif /*End UART_RS485_TXCLKGEN_DP */
            UART_RS485_backup.tx_mask = UART_RS485_TXSTATUS_MASK_REG;
        #endif /*End UART_RS485_TX_ENABLED */


    #else /* CY_UDB_V1 */

        #if(UART_RS485_CONTROL_REG_REMOVED == 0u)
            UART_RS485_backup.cr = UART_RS485_CONTROL_REG;
        #endif /* End UART_RS485_CONTROL_REG_REMOVED */

    #endif  /* End CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: UART_RS485_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART_RS485_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART_RS485_RestoreConfig(void)
{

    #if (CY_UDB_V0)

        #if(UART_RS485_CONTROL_REG_REMOVED == 0u)
            UART_RS485_CONTROL_REG = UART_RS485_backup.cr;
        #endif /* End UART_RS485_CONTROL_REG_REMOVED */

        #if( (UART_RS485_RX_ENABLED) || (UART_RS485_HD_ENABLED) )
            UART_RS485_RXBITCTR_PERIOD_REG = UART_RS485_backup.rx_period;
            UART_RS485_RXSTATUS_MASK_REG = UART_RS485_backup.rx_mask;
            #if (UART_RS485_RXHW_ADDRESS_ENABLED)
                UART_RS485_RXADDRESS1_REG = UART_RS485_backup.rx_addr1;
                UART_RS485_RXADDRESS2_REG = UART_RS485_backup.rx_addr2;
            #endif /* End UART_RS485_RXHW_ADDRESS_ENABLED */
        #endif  /* End (UART_RS485_RX_ENABLED) || (UART_RS485_HD_ENABLED) */

        #if(UART_RS485_TX_ENABLED)
            #if(UART_RS485_TXCLKGEN_DP)
                UART_RS485_TXBITCLKGEN_CTR_REG = UART_RS485_backup.tx_clk_ctr;
                UART_RS485_TXBITCLKTX_COMPLETE_REG = UART_RS485_backup.tx_clk_compl;
            #else
                UART_RS485_TXBITCTR_PERIOD_REG = UART_RS485_backup.tx_period;
            #endif /*End UART_RS485_TXCLKGEN_DP */
            UART_RS485_TXSTATUS_MASK_REG = UART_RS485_backup.tx_mask;
        #endif /*End UART_RS485_TX_ENABLED */

    #else /* CY_UDB_V1 */

        #if(UART_RS485_CONTROL_REG_REMOVED == 0u)
            UART_RS485_CONTROL_REG = UART_RS485_backup.cr;
        #endif /* End UART_RS485_CONTROL_REG_REMOVED */

    #endif  /* End CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: UART_RS485_Sleep
********************************************************************************
*
* Summary:
*  Stops and saves the user configuration. Should be called
*  just prior to entering sleep.
*
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART_RS485_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART_RS485_Sleep(void)
{

    #if(UART_RS485_RX_ENABLED || UART_RS485_HD_ENABLED)
        if((UART_RS485_RXSTATUS_ACTL_REG  & UART_RS485_INT_ENABLE) != 0u)
        {
            UART_RS485_backup.enableState = 1u;
        }
        else
        {
            UART_RS485_backup.enableState = 0u;
        }
    #else
        if((UART_RS485_TXSTATUS_ACTL_REG  & UART_RS485_INT_ENABLE) !=0u)
        {
            UART_RS485_backup.enableState = 1u;
        }
        else
        {
            UART_RS485_backup.enableState = 0u;
        }
    #endif /* End UART_RS485_RX_ENABLED || UART_RS485_HD_ENABLED*/

    UART_RS485_Stop();
    UART_RS485_SaveConfig();
}


/*******************************************************************************
* Function Name: UART_RS485_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called
*  just after awaking from sleep.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  UART_RS485_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void UART_RS485_Wakeup(void)
{
    UART_RS485_RestoreConfig();
    #if( (UART_RS485_RX_ENABLED) || (UART_RS485_HD_ENABLED) )
        UART_RS485_ClearRxBuffer();
    #endif /* End (UART_RS485_RX_ENABLED) || (UART_RS485_HD_ENABLED) */
    #if(UART_RS485_TX_ENABLED || UART_RS485_HD_ENABLED)
        UART_RS485_ClearTxBuffer();
    #endif /* End UART_RS485_TX_ENABLED || UART_RS485_HD_ENABLED */

    if(UART_RS485_backup.enableState != 0u)
    {
        UART_RS485_Enable();
    }
}


/* [] END OF FILE */
