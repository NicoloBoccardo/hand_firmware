/*******************************************************************************
* File Name: AMUXSEQ_MOTORS.c
* Version 1.70
*
*  Description:
*    This file contains functions for the AMuxSeq.
*
*   Note:
*
*******************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "AMUXSEQ_MOTORS.h"

uint8 AMUXSEQ_MOTORS_initVar = 0u;


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_Start
********************************************************************************
* Summary:
*  Disconnect all channels. The next time Next is called, channel 0 will be
*  connected.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void AMUXSEQ_MOTORS_Start(void)
{
    AMUXSEQ_MOTORS_DisconnectAll();
    AMUXSEQ_MOTORS_initVar = 1u;
}


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_Init
********************************************************************************
* Summary:
*  Disconnect all channels. The next time Next is called, channel 0 will be
*  connected.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void AMUXSEQ_MOTORS_Init(void)
{
    AMUXSEQ_MOTORS_DisconnectAll();
}


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_Stop
********************************************************************************
* Summary:
*  Disconnect all channels. The next time Next is called, channel 0 will be
*  connected.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void AMUXSEQ_MOTORS_Stop(void)
{
    AMUXSEQ_MOTORS_DisconnectAll();
}

#if(AMUXSEQ_MOTORS_MUXTYPE == AMUXSEQ_MOTORS_MUX_DIFF)

extern int8 AMUXSEQ_MOTORS_CYAMUXSIDE_A_curChannel;


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_Next
********************************************************************************
* Summary:
*  Disconnects the previous channel and connects the next one in the sequence.
*  When Next is called for the first time after Init, Start, Enable, Stop, or
*  DisconnectAll, it connects channel 0.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void AMUXSEQ_MOTORS_Next(void)
{
    AMUXSEQ_MOTORS_CYAMUXSIDE_A_Next();
    AMUXSEQ_MOTORS_CYAMUXSIDE_B_Next();
}


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_DisconnectAll
********************************************************************************
* Summary:
*  This function disconnects all channels. The next time Next is called, channel
*  0 will be connected.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void AMUXSEQ_MOTORS_DisconnectAll(void)
{
    AMUXSEQ_MOTORS_CYAMUXSIDE_A_DisconnectAll();
    AMUXSEQ_MOTORS_CYAMUXSIDE_B_DisconnectAll();
}


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_GetChannel
********************************************************************************
* Summary:
*  The currently connected channel is retuned. If no channel is connected
*  returns -1.
*
* Parameters:
*  void
*
* Return:
*  The current channel or -1.
*
*******************************************************************************/
int8 AMUXSEQ_MOTORS_GetChannel(void)
{
    return AMUXSEQ_MOTORS_CYAMUXSIDE_A_curChannel;
}

#else

extern int8 AMUXSEQ_MOTORS_curChannel;


/*******************************************************************************
* Function Name: AMUXSEQ_MOTORS_GetChannel
********************************************************************************
* Summary:
*  The currently connected channel is retuned. If no channel is connected
*  returns -1.
*
* Parameters:
*  void
*
* Return:
*  The current channel or -1.
*
*******************************************************************************/
int8 AMUXSEQ_MOTORS_GetChannel(void)
{
    return AMUXSEQ_MOTORS_curChannel;
}

#endif


/* [] END OF FILE */
