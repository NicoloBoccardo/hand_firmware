/*******************************************************************************
* File Name: QuadDec_4_Cnt8_PM.c  
* Version 2.20
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "QuadDec_4_Cnt8.h"

static QuadDec_4_Cnt8_backupStruct QuadDec_4_Cnt8_backup;


/*******************************************************************************
* Function Name: QuadDec_4_Cnt8_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  QuadDec_4_Cnt8_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void QuadDec_4_Cnt8_SaveConfig(void) 
{
    #if (!QuadDec_4_Cnt8_UsingFixedFunction)
        /* Backup the UDB non-rentention registers for PSoC5A */
        #if (CY_PSOC5A)
            QuadDec_4_Cnt8_backup.CounterUdb = QuadDec_4_Cnt8_ReadCounter();
            QuadDec_4_Cnt8_backup.CounterPeriod = QuadDec_4_Cnt8_ReadPeriod();
            QuadDec_4_Cnt8_backup.CompareValue = QuadDec_4_Cnt8_ReadCompare();
            QuadDec_4_Cnt8_backup.InterruptMaskValue = QuadDec_4_Cnt8_STATUS_MASK;
        #endif /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            QuadDec_4_Cnt8_backup.CounterUdb = QuadDec_4_Cnt8_ReadCounter();
            QuadDec_4_Cnt8_backup.InterruptMaskValue = QuadDec_4_Cnt8_STATUS_MASK;
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        #if(!QuadDec_4_Cnt8_ControlRegRemoved)
            QuadDec_4_Cnt8_backup.CounterControlRegister = QuadDec_4_Cnt8_ReadControlRegister();
        #endif /* (!QuadDec_4_Cnt8_ControlRegRemoved) */
    #endif /* (!QuadDec_4_Cnt8_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: QuadDec_4_Cnt8_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  QuadDec_4_Cnt8_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void QuadDec_4_Cnt8_RestoreConfig(void) 
{      
    #if (!QuadDec_4_Cnt8_UsingFixedFunction)     
        /* Restore the UDB non-rentention registers for PSoC5A */
        #if (CY_PSOC5A)
            /* Interrupt State Backup for Critical Region*/
            uint8 QuadDec_4_Cnt8_interruptState;
        
            QuadDec_4_Cnt8_WriteCounter(QuadDec_4_Cnt8_backup.CounterUdb);
            QuadDec_4_Cnt8_WritePeriod(QuadDec_4_Cnt8_backup.CounterPeriod);
            QuadDec_4_Cnt8_WriteCompare(QuadDec_4_Cnt8_backup.CompareValue);
            /* Enter Critical Region*/
            QuadDec_4_Cnt8_interruptState = CyEnterCriticalSection();
        
            QuadDec_4_Cnt8_STATUS_AUX_CTRL |= QuadDec_4_Cnt8_STATUS_ACTL_INT_EN_MASK;
            /* Exit Critical Region*/
            CyExitCriticalSection(QuadDec_4_Cnt8_interruptState);
            QuadDec_4_Cnt8_STATUS_MASK = QuadDec_4_Cnt8_backup.InterruptMaskValue;
        #endif  /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            QuadDec_4_Cnt8_WriteCounter(QuadDec_4_Cnt8_backup.CounterUdb);
            QuadDec_4_Cnt8_STATUS_MASK = QuadDec_4_Cnt8_backup.InterruptMaskValue;
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        #if(!QuadDec_4_Cnt8_ControlRegRemoved)
            QuadDec_4_Cnt8_WriteControlRegister(QuadDec_4_Cnt8_backup.CounterControlRegister);
        #endif /* (!QuadDec_4_Cnt8_ControlRegRemoved) */
    #endif /* (!QuadDec_4_Cnt8_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: QuadDec_4_Cnt8_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  QuadDec_4_Cnt8_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void QuadDec_4_Cnt8_Sleep(void) 
{
    #if(!QuadDec_4_Cnt8_ControlRegRemoved)
        /* Save Counter's enable state */
        if(QuadDec_4_Cnt8_CTRL_ENABLE == (QuadDec_4_Cnt8_CONTROL & QuadDec_4_Cnt8_CTRL_ENABLE))
        {
            /* Counter is enabled */
            QuadDec_4_Cnt8_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            QuadDec_4_Cnt8_backup.CounterEnableState = 0u;
        }
    #endif /* (!QuadDec_4_Cnt8_ControlRegRemoved) */
    QuadDec_4_Cnt8_Stop();
    QuadDec_4_Cnt8_SaveConfig();
}


/*******************************************************************************
* Function Name: QuadDec_4_Cnt8_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  QuadDec_4_Cnt8_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void QuadDec_4_Cnt8_Wakeup(void) 
{
    QuadDec_4_Cnt8_RestoreConfig();
    #if(!QuadDec_4_Cnt8_ControlRegRemoved)
        if(QuadDec_4_Cnt8_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            QuadDec_4_Cnt8_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!QuadDec_4_Cnt8_ControlRegRemoved) */
    
}


/* [] END OF FILE */
