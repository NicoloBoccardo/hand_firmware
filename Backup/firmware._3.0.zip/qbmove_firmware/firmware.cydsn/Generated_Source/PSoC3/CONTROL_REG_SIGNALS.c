/*******************************************************************************
* File Name: CONTROL_REG_SIGNALS.c  
* Version 1.70
*
* Description:
*  This file contains API to enable firmware control of a Control Register.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CONTROL_REG_SIGNALS.h"

#if !defined(CONTROL_REG_SIGNALS_Sync_ctrl_reg__REMOVED) /* Check for removal by optimization */

/*******************************************************************************
* Function Name: CONTROL_REG_SIGNALS_Write
********************************************************************************
*
* Summary:
*  Write a byte to the Control Register.
*
* Parameters:
*  control:  The value to be assigned to the Control Register.
*
* Return:
*  None.
*
*******************************************************************************/
void CONTROL_REG_SIGNALS_Write(uint8 control) 
{
    CONTROL_REG_SIGNALS_Control = control;
}


/*******************************************************************************
* Function Name: CONTROL_REG_SIGNALS_Read
********************************************************************************
*
* Summary:
*  Reads the current value assigned to the Control Register.
*
* Parameters:
*  None.
*
* Return:
*  Returns the current value in the Control Register.
*
*******************************************************************************/
uint8 CONTROL_REG_SIGNALS_Read(void) 
{
    return CONTROL_REG_SIGNALS_Control;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
